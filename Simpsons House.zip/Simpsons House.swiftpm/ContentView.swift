import SwiftUI

struct ContentView: View {
    @State private var lightOn = false
    @State private var fanOn = false
    @State private var doorOpen = false
    @State private var thermostatOn = false
    @State private var log: [String] = []
    
    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "house.fill")
                .resizable()
                .scaledToFit()
                .frame(height: 100)
                .foregroundStyle(
                    LinearGradient(
                        colors: [.black, .gray, .white], 
                        startPoint: .topLeading, 
                        endPoint: .bottomTrailing
                    )
                )
                .shadow(color: .black.opacity(0.5), radius: 10, x: 0, y: 5)

            
            Button {
                withAnimation(.spring()) {
                    lightOn.toggle()
                    add("Light → " + (lightOn ? "on" : "off"))
                }
            } label: {
                HStack {
                    Image(systemName: "lightbulb.fill")
                        .foregroundColor(.white)
                    Text("Light")
                        .foregroundColor(.white)
                    Spacer()
                    Circle()
                        .fill(.white)
                        .frame(width: 15, height: 15)
                        .scaleEffect(lightOn ? 1.2 : 0.8)
                }
                .padding()
                .background(
                    LinearGradient(
                        colors: lightOn ? [.purple, .pink, .blue] : [.black, .blue.opacity(0.3), .purple.opacity(0.3)],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .shadow(color: lightOn ? .yellow.opacity(0.4) : .clear, radius: lightOn ? 8 : 0)
            }
            
            Button {
                withAnimation(.spring()) {
                    fanOn.toggle()
                    add("Fan → " + (fanOn ? "on" : "off"))
                }
            } label: {
                HStack {
                    Image(systemName: "fan.fill")
                        .foregroundColor(.white)
                    Text("Fan")
                        .foregroundColor(.white)
                    Spacer()
                    Circle()
                        .fill(.white)
                        .frame(width: 15, height: 15)
                        .scaleEffect(fanOn ? 1.2 : 0.8)
                }
                .padding()
                .background(
                    LinearGradient(
                        colors: fanOn ? [.purple, .pink, .blue] : [.black, .blue.opacity(0.3), .purple.opacity(0.3)],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .shadow(color: fanOn ? .yellow.opacity(0.4) : .clear, radius: fanOn ? 8 : 0)
            }
            
            Button {
                withAnimation(.spring()) {
                    doorOpen.toggle()
                    add("Door → " + (doorOpen ? "open" : "closed"))
                }
            } label: {
                HStack {
                    Image(systemName: "door.left.hand.open")
                        .foregroundColor(.white)
                    Text("Door")
                        .foregroundColor(.white)
                    Spacer()
                    Circle()
                        .fill(.white)
                        .frame(width: 15, height: 15)
                        .scaleEffect(doorOpen ? 1.2 : 0.8)
                }
                .padding()
                .background(
                    LinearGradient(
                        colors: doorOpen ? [.purple, .pink, .blue] : [.black, .blue.opacity(0.3), .purple.opacity(0.3)],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .shadow(color: doorOpen ? .yellow.opacity(0.4) : .clear, radius: doorOpen ? 8 : 0)
            }
            
            Button {
                withAnimation(.spring()) {
                    thermostatOn.toggle()
                    add("Thermostat → " + (thermostatOn ? "on" : "off"))
                }
            } label: {
                HStack {
                    Image(systemName: "thermometer.sun.circle")
                        .foregroundColor(.white)
                    Text("Thermostat")
                        .foregroundColor(.white)
                    Spacer()
                    Circle()
                        .fill(.white)
                        .frame(width: 15, height: 15)
                        .scaleEffect(thermostatOn ? 1.2 : 0.8)
                }
                .padding()
                .background(
                    LinearGradient(
                        colors: thermostatOn ? [.purple, .pink, .blue] : [.black, .blue.opacity(0.3), .purple.opacity(0.3)],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .shadow(color: thermostatOn ? .yellow.opacity(0.4) : .clear, radius: thermostatOn ? 8 : 0)
            }
            
            // Activity Log
            VStack(alignment: .leading, spacing: 6) {
                Text("Activity Log").font(.headline)
                ScrollView {
                    VStack(alignment: .leading, spacing: 4) {
                        ForEach(log.indices, id: \.self) { i in
                            Text(log[i]).font(.caption).monospaced()
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(6)
                                .background(Color(.secondarySystemBackground))
                                .clipShape(RoundedRectangle(cornerRadius: 6))
                        }
                    }
                }
                Button("Clear Log") { log.removeAll() }
            }
            .padding()
            
            Spacer()
        }
        .padding()
        .background(
            LinearGradient(
                colors: [.black, .blue.opacity(0.3), .purple.opacity(0.3)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .onAppear { add("App started") }
    }
    
    private func add(_ entry: String) {
        let t = DateFormatter()
        t.dateFormat = "HH:mm:ss"
        let time = t.string(from: Date())
        log.append("\(time) • \(entry)")
    }
}

#Preview { ContentView() }
